/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package homework3;

import java.io.FileNotFoundException;
import java.util.HashSet;


public class HomeWork3 {
    
         
    public static void main(String[] args) throws FileNotFoundException {
     
        
     StudentData obj = new StudentData() ;   
     Channing ch = new Channing(obj) ; 
     OpenAddressing open = new OpenAddressing(obj) ;
  
     
     
     
    }
    
}
